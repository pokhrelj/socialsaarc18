
# SAARC Tweets: From 'So What' To 'Show Me That'

## A programmatic look into a corpus of tweets about a South Asian summit



## BEGINNING WITH A BIT OF BACKGROUND

#### Response to a Challenge

This is a description of a programmatic exploration into a significant number of tweets about a regional summit of the South Asian heads of state and government, who had gathered in Kathmandu, Nepal's capital, at the end of November 2014. The exploration mainly responds to a challenge in designing and documenting a reproducible process of deriving insights from a corpus of unstructured texts. An old-time journalist, in his newfangled digital pursuit, had collected the public tweets in his personal spreadsheet archive, so he naturally chose this as his corpus to look into the manifest features of the social conversation of a particular time and milieu. As the work evolves, the algorithms and analyses, based on Python codes, foreground the top actors (users and mentions), actions (tweets and re-tweets), topics (hash-tags and word-bags), and other manifest text features, be they standing tall on their own or sitting in their relations with one another, dates, locations or languages.

#### The Corpus and Serendipity

In October 2014, the author, an English newspaper editor, had set up a personal Google spreadsheet, a copy of TAGS v6.0, to automatically pull and archive tweets about the 18th edition of the South Asian Association for Regional Cooperation, popular in short as SAARC, to keep a tab on possible social media leads for the news coverage of the summit. The region's leaders were formally meeting on November 25 and 26. The social media, in general, had been sharing the news and views in anticipation of the event.

On Twitter, users were sending about 300 SAARC-related tweets and re-tweets, as the first day's archive would show later. So what? Would the trickles add up to be a robust slice of South Asian social conversation? This question, albeit nagging, did not deter the machine from making its hourly automated crawls in search of tweets containing 'SAARC' in their text strings and auto-archiving the results within the collection rate and access period limits set by the micro-blogging platform. The first tweet landed in the archive with a timestamp of 'Fri Oct 31 02:38:57 +0000 2014'. Over the days, the search routines began to yield results by the thousands. The corpus swelled. In a month and a half, about a hundred thousand tweets ended up in the collection, with '1536860' tokens in all, waiting for this serendipitous analysis.

#### Promise of Exploration

For sure, many people across South Asia and beyond were talking about SAARC. Knowing which handles, platforms and actions dominated the conversation; which hashtags and word tokens were shared the most; and which nouns, adjectives, verbs and even gerunds topped the tally of tweets held the promise to generate insights into the nature of social conversation identifiable in some ways with a fifth of the world's humanity that lived in this region of the global south. An exploration into these concepts in a particular moment in SAARC history would be worthwhile in itself, even if it delivered no great insight.

#### The Author and Audience

The author's basic familiarity with text processing routines in Python, a low entry-barrier programming language, and his passion to play with the digital tools in ripping assorted texts apart and joining them back in different ways for fun lured him to respond to mining the collection of SAARC tweets for insights. So, anyone interested in text analysis with simple Python codes or in the social conversation about SAARC per se, for that matter, will find this exploration worth a look. Hopefully, the author assumes, some readers will also say: "Will you show me that, too?"

## OBJECTIVES

The general objective of the present work is to apply Python routines and sub-routines for an exploration of manifest textual features of about a hundred thousand tweets available in the author's local archive pertaining to the 18th SAARC summit.

Specifically, the programmatic analysis will call up existing algorithms, available in Python 3.6 modules and packages, to solve the following tasks towards the exploration of the SAARC related tweets.

#### The Tasks at Hand

•	Import the corpus of tweets

•	Clean and process the text for creating structures amenable for analysis and visualization

•	Describe and analyze the data

•	Visualize the findings

•	Share the text analytic routines and sub-routines used in the process for every step of the way




## METHOD: EXISTING ALGORITHMS USED ONCE AGAIN

The main challenge in meeting the objectives of this study was to come up with a process of exploration that could separate the wheat from the chaff, helping us take stock of the entire body of tweets with clean algorithmic sweeps, eventually visualizing the top actors (users and mentions), top actions (tweets and re-tweets), top topics (hash-tags and word-bags), and other top text features.

Python 3.6, with csv, pandas, numpy and nltk, was used to import, clean, process, analyze and visualize the unstructured texts in a series of following steps.

#### Step 1. Importing and reading the corpus
    
    1.1 Import a local csv file containing the corpus of tweets downloaded from a Google spreadsheet
    1.2 Read the rows of the file into a list object

#### Step 2. Clean-up and processing of the data
	
    2.1 Get the data from the local file to create and populate new lists of interest
    
    2.2 Create a data frame from the newly populated lists
    
        2.2.1 Create bags of tokens for non-empty data in each column of the data frame
    
        2.2.2 From the body of texts per se, create separate lists for user actions (tweets and re-tweets)
    
        2.2.3 From the body of texts per se, create lists of hashtags and other word tokens
    
        2.2.4 Put all the word tokens from the entire corpus into a big bag of words
    
        2.2.5 From the body of texts per se, Create lists of verbs, adjectives and gerunds
    
        2.2.6 Extract the default dates, locations and languages
	
    2.3 Create bags of tokens for user action, pure-tweets and re-tweets, etc
	
#### Step 3. Findings and analyses of the processed data
	
    3.1 Describe the size of data in the lists of interest
	
    3.2 Describe the data frame
	
    3.3 Explore the relations of interest (over user actions, dates, places, languages)

#### Step 4. Results shown in graphs and charts
	
    4.1 Most frequent users, tweets, days, places, 	languages, reply_tos, sources, followers and followees
	
    4.2 Most frequent days and places in the corpus
    
    4.3 Relations of interest (over user actions, dates, places, languages, etc)

#### Step 5. Conclusion

This response to a challenge in ananlyzing unstructured texts for dominant concepts and themes brought an old corpus of tweets, stored in a personal spreadsheet, to light by the sheer virtue of serendipity. The archiver, a newspaper journalist and author of this write-up, decided to explore the collection of about a hundred thousand tweets to find which users and tokens topped the total tally, or how were they related within their token groups and with others.

Python routines and sub-routines made it easy to import the corpus of tweets, clean and process it, analyze the concepts and themes, and visualize the findings while sharing the analytic routines and codes every step of the way.


### Main limitations

Some text cleaning and processing routines were not followed during this analysis because it mainly sought to highlight the core process of analysis of a large volume of unstructured text, not about handling the disparate, locale-based, spelling-error-filled texts that tweets often are. The focus was on importing the csv file, reading it row by row, then ripping the columns apart into lists of variables of interest, one of which would be the body of tweets per se, and sifting the tokens for analysis within their groups and with other groups. 

###### The following important clean-up and processing routines are missing from this analysis

Tweets in languages other than English have not been taken into account. So the total number of tweets is less than what the analysis shows.

The cleanup process is built around simple routines, without using the powerful regular expressions, lists of stopwords, stemmers, or dictionaries.

Because the letter cases have been left unchanged, many word tokens may have been redundant. 


### PYTHON CODES PUT TO WORK

### The Process: Every Step of the Way

### 1. Importing and reading the corpus

##### 1.1 A local csv file containing the corpus of tweets was a available as downloaded from a Google spreadsheet 


```python
import csv
```


```python
# 1.2 Read the rows of the file into a list object

tweetsarc = []
with open("C:\\Users\\User\\Desktop\\18thsaarc\\tweets18saarc.csv") as f:
    reader = csv.reader(f)
    for row in reader:
        tweetsarc.append(row)
```


```python
len(tweetsarc)
```




    97294



### 2. Cleaning and processing the data


```python
# 2.1 Get the data from the local file to create and populate new lists of interest
```


```python
# 2.1.1 Create lists to collect features of interest from the rows

users, tweets, days, places, languages, reply_tos, sources, followers, followees = [], [], [], [], [], [], [], [], []

```


```python
# 2.1.2 Populate the lists with data from the corpus

for row in tweetsarc[1:]:
    users.append(row[0])
    tweets.append(row[1])
    days.append(row[2])
    places.append(row[3])
    languages.append(row[4])
    reply_tos.append(row[5])
    sources.append(row[6])
    followers.append(row[7])
    followees.append(row[8])
    
```


```python
print("users = ", len(users), " tweets = ", len(tweets), " days = ", len(days), " places = ", len(places), 
     " languages = ", len(languages), " reply_tos = ", len(reply_tos), " sources = ", len(sources), " followers = ", len(followers), 
     " followees = ", len(followees))
```

    users =  97293  tweets =  97293  days =  97293  places =  97293  languages =  97293  reply_tos =  97293  sources =  97293  followers =  97293  followees =  97293
    


```python
# 2.2 Create a data frame from the newly populated lists

import pandas as pd
saarc18df = pd.DataFrame({"tweeple": users, "text": tweets, "date": days, "location": places, "lang": languages, "reply": reply_tos, "platform": sources, "fan": followers, "friend": followees})

```


```python
# 2.2.1 Create bags of tokens for each column of the data frame

# For a quick look to the column names

saarc18df.head(0)
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date</th>
      <th>fan</th>
      <th>friend</th>
      <th>lang</th>
      <th>location</th>
      <th>platform</th>
      <th>reply</th>
      <th>text</th>
      <th>tweeple</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>




```python
# 2.2.1.1 Naming bags from column names, just for the heck of it
datt, fann, frenn, langg, locc, platt, repp, textt, tweepple = [], [], [], [], [], [], [], [], []
```


```python
# 2.2.1.2 Populating the bags

for dat in saarc18df['date'][0:]:
    if dat != "":
        datt.append(dat[-26:-20])
    
for fa in saarc18df['fan']:
    if fa != "":
        fann.append(int(fa))

for fr in saarc18df['friend']:
        if fr != "":
            frenn.append(int(fr))

for langs in saarc18df['lang']:
    if langs != "":
        langg.append(langs)

for loc in saarc18df['location']:
    if loc != "":
        locc.append(loc)

for plat in saarc18df['platform']:
    if plat != "":
        platt.append(plat)

for rep in saarc18df['reply']:
    if rep != "":
        repp.append(rep)        

for tex in saarc18df['text']:
    if tex != "":
        textt.append(tex.split(" "))

for tweep in saarc18df['tweeple']:
    if tweep != "":
        tweepple.append(tweep)
```


```python
# For a glimpse of the size of the bags
print ("Size of bags: datt = ", len(datt), ", fann = ", len(fann), ", frenn = ", len(frenn), ", langg = ", len(langg), 
       ", locc = ", len(locc), ", platt = ", len(platt), ", repp = ", len(repp), ", textt = ", len(textt), ", tweepple = ", len(tweepple))
```

    Size of bags: datt =  90914 , fann =  90549 , frenn =  88695 , langg =  90914 , locc =  1491 , platt =  90913 , repp =  3572 , textt =  90914 , tweepple =  90914
    


```python
# 2.2.2 From the body of texts per se, create separate lists for user actions (pure tweets, or PTs, and re-tweets, RTs)

PTs = []
RTs = []

for line in tweets:
    if line.startswith("RT"):
        RTs.append(line)
    else:
        PTs.append(line)
```


```python
print ("Size of pure tweets =", len(PTs), " Size of re-tweets =", len(RTs))
```

    Size of pure tweets = 52616  Size of re-tweets = 44677
    


```python
# 2.2.3 From the body of tweets per se, create lists of hashtags and other word tokens
# Tearing the text apart to see what tokens are in it

hashtags, mentions, weblinks, ingwords, descwords, otherwords = [], [], [], [], [], []

for line in tweets:
    for word in line.split(" "):
        if word.startswith("#"):
            hashtags.append(word)
        elif word.startswith("@"):
            mentions.append(word)
        elif word.startswith("http://"):
            weblinks.append(word)
        elif word.endswith("ing"):
            ingwords.append(word)
        elif word.endswith("est"):
            descwords.append(word)
        else:
            otherwords.append(word)
```


```python
print("hashtags = ", len(hashtags), "mentions = ", len(mentions),"weblinks = ", len(weblinks), "ingwords = ", len(ingwords), "descwords = ", len(descwords), "otherwords = ", len(otherwords))
```

    hashtags =  66668 mentions =  68708 weblinks =  62863 ingwords =  27599 descwords =  2199 otherwords =  1308823
    


```python
# 2.2.4 Put all the word tokens from the entire corpus into a big bag of words

bagofword = []

for line in tweets:
    for word in line.split(" "):
        bagofword.append(word)
```


```python
len(bagofword)
```




    1536860




```python
# 2.2.5 From the body of tweets and retweets (user actions), create lists of verbs, adjectives and gerunds

hashtagsPTs, mentionsPTs, weblinksPTs, ingwordsPTs, descwordsPTs, otherwordsPTs = [], [], [], [], [], [] 
hashtagsRTs, mentionsRTs, weblinksRTs, ingwordsRTs, descwordsRTs, otherwordsRTs = [], [], [], [], [], []

for line in PTs:
    for word in line.split(" "):
        if word.startswith("#"):
            hashtagsPTs.append(word)
        elif word.startswith("@"):
            mentionsPTs.append(word)
        elif word.startswith("http://"):
            weblinksPTs.append(word)
        elif word.endswith("ing"):
            ingwordsPTs.append(word)
        elif word.endswith("est"):
            descwordsPTs.append(word)
        else:
            otherwordsPTs.append(word)

for line in RTs:
    for word in line.split(" "):
        if word.startswith("#"):
            hashtagsRTs.append(word)
        elif word.startswith("@"):
            mentionsRTs.append(word)
        elif word.startswith("http://"):
            weblinksRTs.append(word)
        elif word.endswith("ing"):
            ingwordsRTs.append(word)
        elif word.endswith("est"):
            descwordsRTs.append(word)
        else:
            otherwordsRTs.append(word)
```


```python
print ("hashtags --> ", len(hashtagsPTs), "in pure tweets ", len(hashtagsRTs), "in re-tweets;", 
       "mentions --> ", len(mentionsPTs), "in pure tweets ", len(mentionsRTs),"in re-tweets;",
       "weblinks -->",len(weblinksPTs), "in pure tweets ", len(weblinksRTs),"in re-tweets;",
       "ingwords --> ",len(ingwordsPTs), "in pure tweets ", len(ingwordsRTs), "in re-tweets;",
       "descwords -->", len(descwordsPTs), "in pure tweets ", len(descwordsRTs),"in re-tweets;",
       "otherwords --> ",len(otherwordsPTs), "in pure tweets ", len(otherwordsRTs), "in re-tweets")
```

    hashtags -->  32722 in pure tweets  33946 in re-tweets; mentions -->  11638 in pure tweets  57070 in re-tweets; weblinks --> 36405 in pure tweets  26458 in re-tweets; ingwords -->  11584 in pure tweets  16015 in re-tweets; descwords --> 1419 in pure tweets  780 in re-tweets; otherwords -->  647994 in pure tweets  660829 in re-tweets
    


```python
# 2.2.6 Extract the default dates, locations and languages
```


```python
# Checking to see what the dates look like by default
saarc18df['date'][0:10]
```




    0    Tue Dec 16 09:05:17 +0000 2014
    1    Tue Dec 16 08:58:20 +0000 2014
    2    Tue Dec 16 08:58:03 +0000 2014
    3    Tue Dec 16 08:46:50 +0000 2014
    4    Tue Dec 16 08:46:50 +0000 2014
    5    Tue Dec 16 08:36:29 +0000 2014
    6    Tue Dec 16 08:28:07 +0000 2014
    7    Tue Dec 16 08:26:18 +0000 2014
    8    Tue Dec 16 08:20:52 +0000 2014
    9    Tue Dec 16 08:09:29 +0000 2014
    Name: date, dtype: object




```python
# Collecting the post marks for tweets, sifting for days and months in the date strings
postsdate = []
for day in saarc18df['date'][:]:
    postsdate.append(day.split(" "))
```


```python
# Days parsed, for example
postsdate[0:3]
```




    [['Tue', 'Dec', '16', '09:05:17', '+0000', '2014'],
     ['Tue', 'Dec', '16', '08:58:20', '+0000', '2014'],
     ['Tue', 'Dec', '16', '08:58:03', '+0000', '2014']]




```python
# Populating the days of the week with post marks on the tweets
sundays, mondays, tuesdays, wednesdays, thursdays, fridays, saturdays = [], [], [], [], [], [], []
for num in postsdate[0:]:
    if "Sun" in num:
        sundays.append(num[2])
    elif "Mon" in num:
        mondays.append(num[2])
    elif "Tue" in num:
        tuesdays.append(num[2])
    elif "Wed" in num:
        wednesdays.append(num[2])
    elif "Thu" in num:
        thursdays.append(num[2])
    elif "Fri" in num:
        fridays.append(num[2])
        saturdays.append(num[2])

```


```python
# Tweets by days in the months of October, November and December 2014 as collected in the corpus
novdays, decdays, octdays = [], [], []
for num in postsdate[0:]:
    if "Nov" in num:
        novdays.append(int(num[2]))
    elif "Dec" in num:
        decdays.append(int(num[2]))
    elif "Oct" in num:
        octdays.append(int(num[2]))    
```


```python
# Number of posts by months
print("Tweets for November = ", len(novdays), ", Tweets for December = ", len(decdays), ", Tweets for October = ", len(octdays))
```

    Tweets for November =  88138 , Tweets for December =  2488 , Tweets for October =  288
    


```python
# Putting the tweets in baskets by nation

countries = ["Nepal", "Bhutan", "Bangladesh", "India", "Pakistan", "Sri Lanka", "Maldives", "Afghanistan", "China", "Japan", "USA"]

basketnations = []

for word in countries:
    for line in textt:
        if word in line:
            basketnations.append(word)            
```


```python
# Putting tweets with names of countries inside the list with the country's name 

nepal, bhutan, bangladesh, india, pakistan, srilanka, maldives, afghanistan, china, japan, usa = [], [], [], [], [], [], [], [], [], [], [] 

for word in countries:
    for line in textt:
        if countries[0] in line:
            nepal.append(line)
        elif countries[1] in line:
            bhutan.append(line)
        elif countries[2] in line:
            bangladesh.append(line)
        elif countries[3] in line:
            india.append(line)
        elif countries[4] in line:
            pakistan.append(line)
        elif "Sri" and "Lanka" in line:
            srilanka.append(line)
        elif countries[6] in line:
            maldives.append(line)
        elif countries[7] in line:
            afghanistan.append(line)
        elif countries[8] in line:
            china.append(line)
        elif countries[9] in line:
            japan.append(line)
        elif "US" in line:
            usa.append(line)
        
```


```python
# The sizes of tweets for countries
print ("nepal = ", len(nepal), "bhutan = ", len(bhutan), "bangladesh = ", len(bangladesh), "india = ", len(india), 
       "pakistan = ", len(pakistan), "srilanka = ", len(srilanka), "maldives = ", len(maldives), 
       "afghanistan = ", len(afghanistan), "japan = ", len(japan), "usa = ", len(usa))
```

    nepal =  98802 bhutan =  3388 bangladesh =  6039 india =  73854 pakistan =  56045 srilanka =  3443 maldives =  1683 afghanistan =  4103 japan =  253 usa =  1386
    


```python
# The types of tweets for countries
print(nepal[0:2], bhutan[0:2], bangladesh[0:2], india[0:2], pakistan[0:2], srilanka[0:2], maldives[0:2], afghanistan[0:2], china[0:2], japan[0:2], usa[0:2])
```

    [['RT', '@narendramodi:', 'Leaving', 'for', 'Nepal', 'to', 'attend', 'the', 'SAARC', 'Summit.'], ['RT', '@narendramodi:', 'I', 'thank', 'the', 'people', 'of', 'Nepal', 'for', 'their', 'warm', 'hospitality.', 'My', 'thanks', 'to', 'PM', 'Koirala', 'for', 'being', 'a', 'wonderful', 'host', 'during', 'the', 'SAA…']] [['SAARC', 'fails', 'to', 'confront', 'the', 'Bhutan', 'refugee', 'issue:', 'http://t.co/an2wxH3Djb'], ['RT', '@timesnow:', 'PM', 'of', 'Bhutan', 'Tshering', 'Tobgay', 'welcomes', 'PM', 'Narendra', "Modi's", 'leadership', 'role', 'in', 'SAARC:', 'MEA', '#PMAtSAARC', 'http://t.co/NbKWC0t3cX']] [['#bdnews', '#bangladesh', '18th', 'SAARC', 'Summit:', 'A', 'Perspective', 'From', 'Bangladesh', '–', 'Analysis:', 'After', 'a', 'three-year', 'gap,', 'leade...', 'http://t.co/8kPUSH6sA7'], ['18th', 'SAARC', 'Summit:', 'A', 'Perspective', 'From', 'Bangladesh', '–', 'Analysis', 'http://t.co/v2nXvaKttk']] [['India', 'cannot', 'wait', 'indefinitely', 'for', 'Saarc', 'to', 'become', 'an', 'effective', 'grouping', '-', 'http://t.co/wb5ILNwCNt', '#GoogleAlerts'], ['@YusufDFI', 'India', 'is', 'fighting', 'terror', '&amp;', 'facing', 'prob', 'from', 'Pak', 'in', 'SAARC', 'etc', '&amp;', 'bollywood', 'is', 'busy', 'in', 'casting', 'new', 'Pak', 'actors', 'https://t.co/NkoXgHmuEG']] [['Pakistan', 'bata', 'tapailai', 'miss-call', 'aayo', 'bhane', 'k', 'huncha?', 'Malai', 'ahile', 'testai', 'bhairako', 'cha.', '#Kuro', '#MissedCall', '#SAARC'], ['#PakistanZindabaad', '#rt', 'Unique', 'encyclopedia', 'site:', 'Eclipsing', 'border', 'are', '2', '#democrats', 'united', 'against', 'Pakistan', 'Army', 'http://t.co/v0f2M4JZnr']] [['@ShirazHassan', '#callfor', 'my', 'views', 'on', 'how', 'SAARC', 'member', 'Sri', 'Lanka', 'needs', 'to', 'move', 'on', 'from', 'Mahinda', 'Rajapakse', 'days', 'http://t.co/yWmu6cHSnN'], ['RT', '@PMOIndia:', 'With', 'Sri', 'Lanka', 'we', 'have', 'transformed', 'trade', 'through', 'a', 'Free', 'Trade', 'Agreement:', 'PM', '@narendramodi', 'at', 'the', 'SAARC', 'Summit.', '@PresRajapaksa']] [['brahim', 'Zaki,', 'the', 'former', 'SAARC', 'Secretary', 'General', 'from', 'the', 'Maldives', 'will', 'speak', 'on', '‘Combating', 'Challenges', 'to', 'Democracy', ':', 'A', 'Maldivian', 'Perception'], ['Which', 'SAARC', 'country', 'has', 'the', 'hightest', 'per\ncapita', 'income', '?\na.', 'Bangladesh\nb.', 'India\nc.', 'Nepal\nd.', 'Maldives']] [['I', 'liked', 'a', '@YouTube', 'video', 'http://t.co/KnvynCxAoh', 'President', 'Afghanistan', 'Ashraf', 'Ghani', 'Speech', 'at', '18th', 'SAARC', 'Summit', 'November', '26,', '2014'], ['RT', '@PrakashJavdekar:', 'Hosted', 'dinner', 'for', 'SAARC', 'country', 'ministers-Bhutan,', 'Nepal,', 'Pakistan,', 'Bangladesh,', 'Maldives,', 'Afghanistan', '&amp;', 'Sri', 'Lanka.', 'Agre…']] [['RT', '@rudrapangeni:', 'RT', '@SIBMPune:', 'Dr', '@ramsmahat:Trade', 'costs', 'in', 'SAARC', 'region', 'extremely', 'high;trade', 'between', 'USA', '&amp;', 'China', 'is', 'cheaper', 'than', 'between', '…'], ['RT', '@rudrapangeni:', 'RT', '@SIBMPune:', 'Dr', '@ramsmahat:Trade', 'costs', 'in', 'SAARC', 'region', 'extremely', 'high;trade', 'between', 'USA', '&amp;', 'China', 'is', 'cheaper', 'than', 'between', '…']] [['@aapkipreeti', 'Japan', 'promised', '$32billion', 'investments,', 'President', 'Obama', 'visiting', 'India,regional', 'power', 'in', 'South', 'Asia', 'with', 'SAARC', '@asifakhanbjp'], ['Japan', 'to', 'collaborate', 'in', 'DDR,', 'engergy', 'in', 'SAARC:', 'Japanese', 'observer', 'http://t.co/yLAvEYR59O', 'via', '@setopati']] [['Day-10:', 'US', 'CONTACT', 'program', 'of', 'Saarc', 'rising', 'professionals', '(Dec,', '13,', '2014)\n\nClimbing', 'up', 'of', 'the', 'peak....'], ['Russia', 'will', 'invest', '100', 'Billion', 'dollars', 'in', 'India.', 'Pressure', 'on', 'US', 'as', 'Obama', 'visits', 'Delhi', 'in', 'January.', 'At', 'this', 'rate,', 'SAARC', 'can', 'have', 'its', 'own', 'bank']]
    

### Findings In A Nutshell

##### Size of corpus = 97294 rows of text 

(with information about users, tweets, days, places, languages, reply_tos, sources, followers, followees)

##### Instances available for analysis (out of total records for each column, that is, 97293, after removing the header row) 

users = 90914 (out of 97293),  tweets = 90914,  days (timestamps) = 90914,  places = 1491,  languages =  90914,  reply_tos = 3572, sources = 90913, 97293,  followers = 90549, followees = 88695

##### Number of tokens in tweets = 1536860

###### User action

Pure tweets = 52616, Re-tweets = 44677

hashtags -->  32722 in pure tweets  33946 in re-tweets; mentions -->  11638 in pure tweets  57070 in re-tweets; weblinks --> 36405 in pure tweets  26458 in re-tweets; ingwords -->  11584 in pure tweets  16015 in re-tweets; descwords --> 1419 in pure tweets  780 in re-tweets; otherwords -->  647994 in pure tweets  660829 in re-tweets

###### Other features from the entire body of tweets

hashtags = 66668, mentions = 68708, weblinks = 62863, ingwords = 27599, descwords = 2199, otherwords = 1308823

##### Tweets by month

Tweets for November = 88138, Tweets for December = 2488, Tweets for October = 288

#### Mention in tweets for countries

nepal =  98802 bhutan =  3388 bangladesh =  6039 india =  73854 pakistan =  56045 srilanka =  3443 maldives =  1683 afghanistan =  4103 japan =  253 usa =  1386

## Analysis with Simple Graphs


```python
import nltk
```


```python
fdistdate = nltk.FreqDist(datt)
```


```python
fdistdate.plot(10, cumulative = False) 
```


![png](output_42_0.png)



```python
fdistlang = nltk.FreqDist(langg)
```


```python
fdistlang.plot(20, cumulative = False)
```


![png](output_44_0.png)



```python
fdistlocation = nltk.FreqDist(locc)
fdistlocation.plot(20, cumulative = False)
```


![png](output_45_0.png)



```python
fdistplatform = nltk.FreqDist(platt)
fdistplatform.plot(20, cumulative = False)
```


![png](output_46_0.png)



```python
fdistreply = nltk.FreqDist(repp)
fdistreply.plot(20, cumulative = False)
```


![png](output_47_0.png)



```python
fdisttext = nltk.FreqDist(bagofword)
fdisttext.plot(10, cumulative = False)
```


![png](output_48_0.png)



```python
fdisttweeple = nltk.FreqDist(saarc18df['tweeple'])
fdisttweeple.plot(20, cumulative = False)
```


![png](output_49_0.png)



```python
fdistnovdays = nltk.FreqDist(novdays)
fdistnovdays.plot(10, cumulative = False)
```


![png](output_50_0.png)



```python
fdistdecdays = nltk.FreqDist(decdays)
fdistdecdays.plot(10, cumulative = False)
```


![png](output_51_0.png)



```python
fdistoctdays = nltk.FreqDist(octdays)
fdistoctdays.plot(10, cumulative = False)
```


![png](output_52_0.png)



```python
fdistsundays = nltk.FreqDist(sundays)
fdistsundays.plot(5, cumulative = False)
```


![png](output_53_0.png)



```python
fdistmondays = nltk.FreqDist(mondays)
fdistmondays.plot(5, cumulative = False)
```


![png](output_54_0.png)



```python
fdisttuesdays = nltk.FreqDist(tuesdays)
fdisttuesdays.plot(5, cumulative = False)
```


![png](output_55_0.png)



```python
fdistwednesdays = nltk.FreqDist(wednesdays)
fdistwednesdays.plot(5, cumulative = False)
```


![png](output_56_0.png)



```python
fdistthursdays = nltk.FreqDist(thursdays)
fdistthursdays.plot(5, cumulative = False)
```


![png](output_57_0.png)



```python
fdistfridays = nltk.FreqDist(fridays)
fdistfridays.plot(5, cumulative = False)
```


![png](output_58_0.png)



```python
fdistsaturdays = nltk.FreqDist(saturdays)
fdistsaturdays.plot(5, cumulative = False)
```


![png](output_59_0.png)



```python
fdistmentions = nltk.FreqDist(mentions)
fdistmentions.plot(20, cumulative = False)
```


![png](output_60_0.png)



```python
fdistweblinks = nltk.FreqDist(weblinks)
fdistweblinks.plot(20, cumulative = False)
```


![png](output_61_0.png)



```python
fdistingwords = nltk.FreqDist(ingwords)
fdistingwords.plot(20, cumulative = False)
```


![png](output_62_0.png)



```python
fdisthashtags = nltk.FreqDist(hashtags)
fdisthashtags.plot(25, cumulative = False)
```


![png](output_63_0.png)



```python
fdistbasketnations = nltk.FreqDist(basketnations)
fdistbasketnations.plot(25, cumulative = False)
```


![png](output_64_0.png)


## Conclusion

This response to a challenge in ananlyzing unstructured texts for dominant concepts and themes brought an old corpus of tweets, stored in a personal spreadsheet, to light by the sheer virtue of serendipity. The archiver, a newspaper journalist and author of this write-up, decided to explore the collection of about a hundred thousand tweets to find which users and tokens topped the total tally, or how they were related within their token groups and with others.

Python routines and sub-routines made it easy to import the corpus of tweets, clean and process it, analyze the concepts and themes, and visualize the findings while sharing the analytic routines and codes every step of the way.

Simple examples and visualization, mainly line graphs, have been used to aid in the exploration of concepts and themes within their groups. Importing a corpus of tweets about SAARC, an important regional grouping of South Asian nations, where one fifth of the world's population lives, the programmatic analysis built on the justification that the conversation on the popular social media platform may yield interesting insights. It examined the tweets token by token, creating lists and bags of words, from which top concepts were extracted and converted into numbers, making them amenable for clean visual rendering. 

Some of the analysis may have confirmed some of our hunches, such as Nepal, the host country, receiving the most mentions among countries, while others may have thrown surprises, such as user action of sending retweets contained mentions of other users several times more often than their action of sending tweets. 

In the least, this work has shown that it is worthwhile and practical to monitor the social media conversation as a surrogate space that engages the population in talks, where users can say everything about everything, so the researcher might find something of wider social interest.

#### Limitations

Some text cleaning and processing routines were not followed during this analysis because it mainly sought to highlight the core process of analysis of a large volume of unstructured text, not about handling the disparate, locale-based, spelling-error-filled texts that tweets often are. The focus was on importing the csv file, reading it row by row, then ripping the columns apart into lists of variables of interest, one of which would be the body of tweets per se, and sifting the tokens for analysis within their groups and with other groups.

##### The following important clean-up and processing routines are missing from this analysis

Tweets in languages other than English have not been taken into account. So the total number of tweets is less than what the analysis shows.

The cleanup process is built around simple routines, without using the powerful regular expressions, lists of stopwords, stemmers, or dictionaries.

Because the letter cases have been left unchanged, many word tokens may have been redundant.
